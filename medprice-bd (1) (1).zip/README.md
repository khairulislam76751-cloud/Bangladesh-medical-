# Medicine Price BD
Deploy (Vercel/any Node host + managed PostgreSQL, HTTPS):
1. `cp .env.example .env` and fill DATABASE_URL, AUTH_SECRET (`openssl rand -hex 32`), ADMIN_EMAIL, ADMIN_PASSWORD
2. `npm install && npx prisma db push && npm run seed && npm run build && npm start`
3. Admin at `/admin`. Reset admin password: change ADMIN_PASSWORD and run `npm run seed`.

## Connecting a data source (PROVIDERS_JSON)
No data source is bundled. Add only sources whose terms permit automated access (official/licensed API or permitted feed). Example shape (replace with a REAL documented endpoint):
[{"name":"<Source name>","url":"https://<real-host>/<real-path>?q={q}","apiKeyEnv":"PROVIDER1_KEY","authHeader":"Authorization","resultsPath":"data.items","priceType":"MRP",
"map":{"brand":"name","generic":"generic","strength":"strength","form":"form","manufacturer":"company","packSize":"pack","packPrice":"mrp","unitPrice":"unit_price"}}]
Put the key in env PROVIDER1_KEY. Providers are tried in order; failures are logged and the next is tried. priceType must truly match what the source states (MRP/SELLING/DISCOUNTED/REFERENCE); otherwise leave it out and the UI shows "MRP যাচাই করা যায়নি".

## Built-in source: DGDA registry (no prices)
Always on as the last provider: official DGDA registered-drug registry via DGHS OCL (`OCL_BASE`, default https://api.tr.ocl.dghs.gov.bd, source MoHFW/DGDA-Drugs). Public read, no key. It has NO prices; no explicit licence is published, so attribute DGDA/DGHS and re-check terms before commercial use.
First check after deploy: open `/api/ocl-sample?q=napa`. The field mapping (generic/company/dosage form from `extras`) was written without seeing a live response; if names look wrong, adjust `ocl()` in lib/providers.ts to the keys shown.
