import {PrismaClient} from '@prisma/client';
const g=globalThis as any;export const prisma:PrismaClient=g.p||(g.p=new PrismaClient());
