import {SignJWT,jwtVerify} from 'jose';
const key=()=>new TextEncoder().encode(process.env.AUTH_SECRET||'');
export const sign=(id:number)=>new SignJWT({id}).setProtectedHeader({alg:'HS256'}).setExpirationTime('8h').sign(key());
export async function verify(t?:string){if(!t||!process.env.AUTH_SECRET)return null;try{return (await jwtVerify(t,key())).payload}catch{return null}}
