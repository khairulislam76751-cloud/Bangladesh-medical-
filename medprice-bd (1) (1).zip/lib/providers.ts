// Provider layer. NO built-in data source: you configure legitimately licensed/permitted sources in PROVIDERS_JSON.
// Each: {name,url:"https://…?q={q}",apiKeyEnv?,authHeader?,resultsPath?,priceType?,map:{brand,generic,strength,form,manufacturer,packSize,packPrice,unitPrice,priceType}}
import {prisma} from './db';
export type Result={brand:string;generic?:string;strength?:string;form?:string;manufacturer?:string;packSize?:string;packPrice?:number|null;unitPrice?:number|null;priceType:string|null;providerName:string;checkedAt:string};
const get=(o:any,p?:string)=>p?p.split('.').reduce((a,k)=>a?.[k],o):o;
const bn='০১২৩৪৫৬৭৮৯';
export function normPrice(v:any):number|null{if(v==null)return null;if(typeof v==='number')return isFinite(v)&&v>=0?v:null;
 const s=String(v).replace(/[০-৯]/g,d=>String(bn.indexOf(d))).replace(/,/g,'').match(/\d+(\.\d+)?/);return s?parseFloat(s[0]):null}
const TYPES=['MRP','SELLING','DISCOUNTED','REFERENCE'];
function providers():any[]{try{return JSON.parse(process.env.PROVIDERS_JSON||'[]')}catch{return[]}}
async function run(c:any,q:string):Promise<Result[]>{
 const url=new URL(c.url.replace('{q}',encodeURIComponent(q)));if(url.protocol!=='https:')throw new Error('https required');
 const h:any={Accept:'application/json'};if(c.apiKeyEnv&&process.env[c.apiKeyEnv])h[c.authHeader||'Authorization']=process.env[c.apiKeyEnv];
 const r=await fetch(url,{headers:h,signal:AbortSignal.timeout(8000),cache:'no-store'});if(!r.ok)throw new Error('HTTP '+r.status);
 const list=get(await r.json(),c.resultsPath);if(!Array.isArray(list))throw new Error('unexpected response shape');
 const m=c.map||{},now=new Date().toISOString();
 return list.map((x:any)=>{const t=String(get(x,m.priceType)??c.priceType??'').toUpperCase();
  return{brand:String(get(x,m.brand)??''),generic:get(x,m.generic),strength:get(x,m.strength),form:get(x,m.form),manufacturer:get(x,m.manufacturer),packSize:get(x,m.packSize),
  packPrice:normPrice(get(x,m.packPrice)),unitPrice:normPrice(get(x,m.unitPrice)),priceType:TYPES.includes(t)?t:null,providerName:c.name,checkedAt:now}}).filter((x:Result)=>x.brand)}
const pick=(o:any,re:RegExp)=>{for(const k of Object.keys(o||{}))if(re.test(k)&&o[k])return String(o[k]);return undefined};
// Official DGDA registry via DGHS terminology server (public, anonymous read). Gives identity data only - NO prices.
export async function oclFetch(q:string):Promise<any[]>{
 const base=(process.env.OCL_BASE||'https://api.tr.ocl.dghs.gov.bd').replace(/\/$/,'');
 const u=new URL(base+'/orgs/MoHFW/sources/DGDA-Drugs/concepts/');
 u.search=new URLSearchParams({q,limit:'25',verbose:'true',includeRetired:'false'}).toString();
 const r=await fetch(u,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(10000),cache:'no-store'});
 if(!r.ok)throw new Error('OCL HTTP '+r.status);const l=await r.json();if(!Array.isArray(l))throw new Error('OCL unexpected response');return l}
async function ocl(q:string):Promise<Result[]>{const now=new Date().toISOString();
 return (await oclFetch(q)).filter((c:any)=>!c.retired&&(!c.concept_class||/drug/i.test(c.concept_class))).map((c:any)=>{
  const ex=c.extras||{};const raw=pick(ex,/generic/i);let generic:any,strength:any;
  if(raw){const a=raw.split(/\s{2,}/);generic=a[0];strength=a.slice(1).join(', ')||undefined}
  return{brand:c.display_name||c.names?.[0]?.name||'',generic,strength,form:pick(ex,/dosage|form/i),manufacturer:pick(ex,/company|manufactur/i),packPrice:null,unitPrice:null,priceType:null,providerName:'DGDA রেজিস্ট্রি (DGHS)',checkedAt:now} as Result}).filter((x:Result)=>x.brand)}
export async function searchAll(q:string){
 const src=[...providers().map((c:any)=>({name:c.name,fn:()=>run(c,q)})),{name:'DGDA-OCL',fn:()=>ocl(q)}];let failed=0;
 for(const c of src){try{const res=await c.fn();await prisma.apiLog.create({data:{provider:c.name,ok:true}});
   if(res.length){const pr=res.filter(r=>r.packPrice!=null||r.unitPrice!=null);
    if(pr.length)await prisma.priceHistory.createMany({data:pr.map(r=>({brand:r.brand,generic:r.generic??null,strength:r.strength??null,form:r.form??null,manufacturer:r.manufacturer??null,price:r.packPrice??null,unitPrice:r.unitPrice??null,priceType:r.priceType,provider:r.providerName}))});
    return{status:'OK',results:res}}}
  catch(e:any){failed++;await prisma.apiLog.create({data:{provider:c.name,ok:false,error:String(e.message).slice(0,300)}})}}
 return{status:failed===src.length?'ALL_FAILED':'EMPTY',results:[] as Result[]}}
