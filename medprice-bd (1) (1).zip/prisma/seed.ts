import {PrismaClient} from '@prisma/client';import bcrypt from 'bcryptjs';
const p=new PrismaClient();
(async()=>{const e=process.env.ADMIN_EMAIL!,pw=process.env.ADMIN_PASSWORD!;
if(!e||!pw||pw.length<10)throw new Error('Set ADMIN_EMAIL and ADMIN_PASSWORD (10+ chars)');
const h=await bcrypt.hash(pw,12);
await p.admin.upsert({where:{email:e},update:{passwordHash:h},create:{email:e,passwordHash:h}});
console.log('Admin ready (re-run to reset password):',e)})();
