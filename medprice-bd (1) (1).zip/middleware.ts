import {NextRequest,NextResponse} from 'next/server';import {verify} from '@/lib/auth';
export async function middleware(r:NextRequest){if(r.nextUrl.pathname==='/api/admin/login')return NextResponse.next();
 if(!(await verify(r.cookies.get('adm')?.value)))return NextResponse.json({error:'unauthorized'},{status:401});return NextResponse.next()}
export const config={matcher:['/api/admin/:path*']};
