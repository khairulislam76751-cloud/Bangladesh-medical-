'use client';
import {useEffect,useState} from 'react';
const T:any={MRP:'MRP',SELLING:'অনলাইন বিক্রয়মূল্য',DISCOUNTED:'ছাড়কৃত মূল্য',REFERENCE:'রেফারেন্স মূল্য'};
const tk=(n:number)=>'৳'+n.toLocaleString('bn-BD',{maximumFractionDigits:2});
const fmt=(s:string)=>new Date(s).toLocaleString('bn-BD');
const btn='min-h-12 px-5 rounded-xl font-semibold bg-emerald-700 text-white active:bg-emerald-800';
const inp='min-h-12 px-4 rounded-xl border border-slate-300 w-full';
export default function Home(){
 const [q,setQ]=useState('');const [res,setRes]=useState<any[]>([]);const [msg,setMsg]=useState('');const [load,setLoad]=useState(false);
 const [list,setList]=useState<any[]>([]);const [budget,setBudget]=useState('');const [content,setContent]=useState<any>({updates:[],ads:[]});const [sel,setSel]=useState<any>(null);
 useEffect(()=>{fetch('/api/content').then(r=>r.json()).then(setContent).catch(()=>{})},[]);
 async function search(e?:any){e?.preventDefault();setMsg('');setRes([]);setSel(null);
  if(!navigator.onLine){setMsg('ইন্টারনেট সংযোগ প্রয়োজন। বর্তমান ওষুধের মূল্য অনলাইন থেকে যাচাই করা যাচ্ছে না।');return}
  setLoad(true);
  try{const r=await fetch('/api/search?q='+encodeURIComponent(q),{cache:'no-store'});const d=await r.json();setRes(d.results||[]);
   setMsg(d.status==='ALL_FAILED'?'বর্তমানে অনলাইন মূল্য যাচাই করা সম্ভব হচ্ছে না। কিছুক্ষণ পরে আবার চেষ্টা করুন।':d.status==='NO_PROVIDER'?'কোনো ডেটা সোর্স সংযুক্ত নেই। অ্যাডমিন সোর্স কনফিগার করুন।':d.status==='SHORT'?'কমপক্ষে ২ অক্ষর লিখুন।':d.results.length?'':'কোনো নির্ভরযোগ্য অনলাইন ফলাফল পাওয়া যায়নি।')}
  catch{setMsg('ইন্টারনেট সংযোগ প্রয়োজন। বর্তমান ওষুধের মূল্য অনলাইন থেকে যাচাই করা যাচ্ছে না।')}
  setLoad(false)}
 const add=(m:any)=>setList(l=>[...l,{...m,qty:1,pharm:''}]);
 const upd=(i:number,k:string,v:any)=>setList(l=>l.map((x,j)=>j===i?{...x,[k]:v}:x));
 const basis=(m:any)=>m.unitPrice!=null?{p:m.unitPrice,unit:true}:m.packPrice!=null?{p:m.packPrice,unit:false}:+m.manual>0?{p:+m.manual,unit:true,manual:true}:null;
 const cost=(m:any)=>{const b=basis(m);return b?b.p*(Number(m.qty)||0):null};
 const total=list.reduce((s,m)=>s+(cost(m)||0),0);const bd=parseFloat(budget);
 return(<main className="max-w-3xl mx-auto p-4 space-y-6">
 <header className="flex items-center gap-3 py-2"><div className="w-12 h-12 rounded-2xl bg-emerald-700 text-white grid place-items-center text-2xl">৳</div><h1 className="text-2xl font-bold text-emerald-900">ওষুধের দাম যাচাই</h1></header>
 <form onSubmit={search} className="space-y-3"><label className="font-semibold">ওষুধের নাম লিখুন</label><input className={inp} value={q} onChange={e=>setQ(e.target.value)} placeholder="ব্র্যান্ড বা জেনেরিক নাম"/><button className={btn+' w-full'} disabled={load}>ওষুধ খুঁজুন</button></form>
 {load&&<p className="text-emerald-800">অনলাইন থেকে ওষুধের তথ্য খোঁজা হচ্ছে...</p>}{msg&&<p className="p-4 rounded-xl bg-amber-50 border border-amber-300">{msg}</p>}
 {res.map((m,i)=>(<div key={i} className="bg-white rounded-2xl shadow p-4 space-y-1">
  <h3 className="text-xl font-bold">{m.brand}</h3><p>{[m.generic,m.strength,m.form].filter(Boolean).join(' · ')}</p><p className="text-sm text-slate-600">{m.manufacturer} {m.packSize&&'· প্যাক: '+m.packSize}</p>
  <p className="font-semibold text-emerald-800">{m.packPrice!=null?`${T[m.priceType]||'মূল্য'}: ${tk(m.packPrice)}`:''}{m.unitPrice!=null&&` · প্রতি ইউনিট: ${tk(m.unitPrice)}`}{m.packPrice==null&&m.unitPrice==null&&'মূল্য পাওয়া যায়নি'}</p>
  {!m.priceType&&<p className="text-amber-700 text-sm">MRP যাচাই করা যায়নি</p>}
  <p className="text-sm text-slate-600">সোর্স: {m.providerName} · সর্বশেষ যাচাই: {fmt(m.checkedAt)}</p>
  <p className="text-xs text-slate-500">এই মূল্য অনলাইন উৎস থেকে সংগৃহীত। কেনার আগে প্যাকেটের গায়ে থাকা MRP যাচাই করুন।</p>
  <button className={btn} onClick={()=>add(m)}>হিসাবে যোগ করুন</button></div>))}
 {list.length>0&&<section className="bg-white rounded-2xl shadow p-4 space-y-4"><h2 className="text-xl font-bold">প্রেসক্রিপশন খরচ ও ফার্মেসির দাম যাচাই</h2>
  {list.map((m,i)=>{const b=basis(m),c=cost(m),ph=parseFloat(m.pharm);return(<div key={i} className="border-b pb-3 space-y-2"><b>{m.brand}</b> <span className="text-sm">{m.strength}</span>
   {m.unitPrice==null&&m.packPrice==null&&<div><label className="block text-sm">সোর্সে দাম নেই — আপনার জানা দাম (প্রতি ইউনিট ৳)</label><input type="number" min="0" className={inp} value={m.manual||''} onChange={e=>upd(i,'manual',e.target.value)}/></div>}
   {b?<><label className="block text-sm">{b.unit?'পরিমাণ (ইউনিট)':'পরিমাণ (প্যাকেট)'}</label><input type="number" min="0" className={inp} value={m.qty} onChange={e=>upd(i,'qty',e.target.value)}/>
   {!b.unit&&<p className="text-sm text-amber-700">প্যাকেটের মূল্য অনুযায়ী আনুমানিক হিসাব</p>}<p>আনুমানিক খরচ: <b>{tk(c!)}</b> <span className="text-xs text-slate-500">({b.manual?'আপনার দেওয়া মূল্য, যাচাইকৃত নয়':m.providerName+', '+fmt(m.checkedAt)})</span></p>
   <input type="number" className={inp} placeholder="ফার্মেসির মূল্য (৳)" value={m.pharm} onChange={e=>upd(i,'pharm',e.target.value)}/>
   {!isNaN(ph)&&<p>রেফারেন্স মূল্য: {tk(b.p)} · ফার্মেসির মূল্য: {tk(ph)} · পার্থক্য: {tk(ph-b.p)}{b.p>0&&` (${((ph-b.p)/b.p*100).toFixed(1)}%)`}</p>}</>:<p className="text-amber-700">মূল্য নেই, হিসাব করা যাচ্ছে না</p>}
   <button className="text-red-700 underline" onClick={()=>setList(l=>l.filter((_,j)=>j!==i))}>বাদ দিন</button></div>)})}
  <p className="text-xl font-bold">মোট আনুমানিক খরচ: {tk(total)}</p>
  <label className="block font-semibold">আমার বাজেট</label><input type="number" className={inp} value={budget} onChange={e=>setBudget(e.target.value)} placeholder="৳"/>
  {!isNaN(bd)&&<p className="font-semibold">{total>bd?`আপনার নির্ধারিত বাজেটের চেয়ে আনুমানিক ${tk(total-bd)} বেশি প্রয়োজন।`:`আপনার বাজেটের মধ্যে আনুমানিক ${tk(bd-total)} অবশিষ্ট থাকবে।`}</p>}</section>}
 {content.updates.length>0&&<section><h2 className="text-xl font-bold mb-2">নতুন আপডেট</h2>{content.updates.map((u:any)=><div key={u.id} className="bg-white rounded-2xl shadow p-4 mb-3">{u.imageUrl&&<img src={u.imageUrl} alt="" className="rounded-xl mb-2 max-h-48 w-full object-cover"/>}<b>{u.title}</b><p>{u.body}</p></div>)}</section>}
 {content.ads.length>0&&<section className="border-2 border-dashed border-slate-300 rounded-2xl p-3"><p className="text-xs text-slate-500 mb-2">বিজ্ঞাপন (ওষুধের তথ্য নয়)</p>{content.ads.map((a:any)=><div key={a.id} className="mb-2">{a.imageUrl&&<img src={a.imageUrl} alt="" className="rounded-xl max-h-40 w-full object-cover"/>}<b>{a.title}</b><p>{a.body}</p>{a.link&&<a className="text-emerald-700 underline" href={a.link} rel="noopener noreferrer sponsored" target="_blank">বিস্তারিত</a>}</div>)}</section>}
<section className="bg-white rounded-2xl shadow p-4 text-sm space-y-1"><h2 className="font-bold">ডেটা সোর্স সম্পর্কে</h2><p>ওষুধের নাম, জেনেরিক, কোম্পানি ও ডোজ ফর্ম নেওয়া হয় DGDA-র নিবন্ধিত ওষুধের সরকারি রেজিস্ট্রি থেকে (DGHS, স্বাস্থ্য মন্ত্রণালয়)। এই রেজিস্ট্রিতে দাম নেই; দাম কেবল তখনই দেখানো হবে যখন একটি যাচাইকৃত দামের সোর্স যুক্ত থাকবে।</p><p>সম্পর্কিত তৃতীয় পক্ষের প্রজেক্ট (আমাদের নয়, তথ্যসূত্র হিসেবে): <a className="text-emerald-700 underline" href="https://github.com/saikatnjm/medicine-price-portal" target="_blank" rel="noopener noreferrer">medicine-price-portal (GitHub)</a></p></section>
 </main>)}
