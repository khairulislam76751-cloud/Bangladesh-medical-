import './globals.css';
export const metadata={title:'ওষুধের দাম যাচাই',description:'ওষুধের মূল্য ও প্রেসক্রিপশন খরচ হিসাব'};
export default function L({children}:{children:React.ReactNode}){return(<html lang="bn"><head><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;600;700&display=swap"/><meta name="viewport" content="width=device-width, initial-scale=1"/></head>
<body className="bg-slate-50 text-slate-800 pb-24">{children}
<div className="fixed bottom-0 inset-x-0 bg-emerald-900 text-white text-sm p-3 text-center">এই অ্যাপটি শুধুমাত্র প্রেসক্রিপশন ও ওষুধের খরচ হিসাব করার জন্য। ওষুধের ডোজ বা চিকিৎসার মেয়াদ পরিবর্তনের জন্য ডাক্তার বা ফার্মাসিস্টের পরামর্শ নিন।</div></body></html>)}
