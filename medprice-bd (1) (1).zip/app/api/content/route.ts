import {NextResponse} from 'next/server';import {prisma} from '@/lib/db';
export const dynamic='force-dynamic';
export async function GET(){const n=new Date();
 const [updates,ads]=await Promise.all([
  prisma.announcement.findMany({where:{status:'PUBLISHED',publishAt:{lte:n},OR:[{expiresAt:null},{expiresAt:{gt:n}}]},orderBy:{publishAt:'desc'},take:10}),
  prisma.advertisement.findMany({where:{active:true,startAt:{lte:n},OR:[{endAt:null},{endAt:{gt:n}}]},take:5})]);
 return NextResponse.json({updates,ads})}
