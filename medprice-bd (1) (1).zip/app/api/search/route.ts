import {NextRequest,NextResponse} from 'next/server';import {searchAll} from '@/lib/providers';import {prisma} from '@/lib/db';
export const dynamic='force-dynamic';
export async function GET(r:NextRequest){const q=(r.nextUrl.searchParams.get('q')||'').trim().slice(0,80);
 if(q.length<2)return NextResponse.json({status:'SHORT',results:[]});
 const out=await searchAll(q);await prisma.searchLog.create({data:{query:q,status:out.status,results:out.results.length}});
 return NextResponse.json(out,{headers:{'Cache-Control':'no-store'}})}
