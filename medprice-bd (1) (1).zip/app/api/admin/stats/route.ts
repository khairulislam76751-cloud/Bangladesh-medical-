import {NextResponse} from 'next/server';import {prisma} from '@/lib/db';
export const dynamic='force-dynamic';
export async function GET(){const [total,ok,fail,users,logs,last]=await Promise.all([prisma.searchLog.count(),prisma.searchLog.count({where:{status:'OK'}}),prisma.searchLog.count({where:{status:'ALL_FAILED'}}),prisma.user.count(),
 prisma.apiLog.findMany({orderBy:{id:'desc'},take:20}),prisma.apiLog.findFirst({where:{ok:true},orderBy:{id:'desc'}})]);
 return NextResponse.json({total,ok,fail,users,logs,lastSuccess:last?.createdAt??null,providersConfigured:(()=>{try{return JSON.parse(process.env.PROVIDERS_JSON||'[]').length}catch{return 0}})()})}
