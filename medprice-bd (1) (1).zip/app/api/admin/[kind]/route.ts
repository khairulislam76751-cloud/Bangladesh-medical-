import {NextRequest,NextResponse} from 'next/server';import {prisma} from '@/lib/db';
const F:any={announcements:{m:'announcement',s:['title','body','imageUrl','status'],d:['publishAt','expiresAt'],o:'publishAt'},ads:{m:'advertisement',s:['title','body','imageUrl','link'],b:['active'],d:['startAt','endAt'],o:'startAt'}};
const url=(v:any)=>{try{return ['http:','https:'].includes(new URL(v).protocol)}catch{return false}};
function pick(c:any,b:any){const o:any={};
 for(const f of c.s)if(b[f]!==undefined){const v=b[f]===''&&!['title','body','status'].includes(f)?null:String(b[f]);
  if(v&&['imageUrl','link'].includes(f)&&!url(v))throw new Error('bad url');o[f]=v}
 if(o.status&&!['DRAFT','PUBLISHED'].includes(o.status))throw new Error('bad status');
 for(const f of c.b||[])if(b[f]!==undefined)o[f]=!!b[f];
 for(const f of c.d)if(b[f]!==undefined)o[f]=b[f]?new Date(b[f]):null;
 if(o.publishAt===null)delete o.publishAt;if(o.startAt===null)delete o.startAt;return o}
const cfg=(k:string)=>F[k];
export async function GET(_:NextRequest,{params}:any){const c=cfg(params.kind);if(!c)return NextResponse.json({},{status:404});
 return NextResponse.json(await (prisma as any)[c.m].findMany({orderBy:{[c.o]:'desc'}}))}
export async function POST(r:NextRequest,{params}:any){const c=cfg(params.kind);if(!c)return NextResponse.json({},{status:404});
 try{const d=pick(c,await r.json());if(!d.title)throw new Error('title');return NextResponse.json(await (prisma as any)[c.m].create({data:d}))}catch(e:any){return NextResponse.json({error:e.message},{status:400})}}
export async function PUT(r:NextRequest,{params}:any){const c=cfg(params.kind);if(!c)return NextResponse.json({},{status:404});
 try{const b=await r.json();return NextResponse.json(await (prisma as any)[c.m].update({where:{id:Number(b.id)},data:pick(c,b)}))}catch(e:any){return NextResponse.json({error:e.message},{status:400})}}
export async function DELETE(r:NextRequest,{params}:any){const c=cfg(params.kind);if(!c)return NextResponse.json({},{status:404});
 await (prisma as any)[c.m].delete({where:{id:Number(r.nextUrl.searchParams.get('id'))}});return NextResponse.json({ok:true})}
