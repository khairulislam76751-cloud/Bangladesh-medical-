import {NextRequest,NextResponse} from 'next/server';import bcrypt from 'bcryptjs';import {prisma} from '@/lib/db';import {sign} from '@/lib/auth';
export async function POST(r:NextRequest){const {email,password}=await r.json().catch(()=>({}));
 const a=typeof email==='string'?await prisma.admin.findUnique({where:{email}}):null;
 const ok=await bcrypt.compare(String(password||''),a?.passwordHash||'$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvali');
 if(!a||!ok)return NextResponse.json({error:'invalid'},{status:401});
 const res=NextResponse.json({ok:true});res.cookies.set('adm',await sign(a.id),{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'strict',path:'/',maxAge:28800});return res}
