import {NextRequest,NextResponse} from 'next/server';import {oclFetch} from '@/lib/providers';
export const dynamic='force-dynamic';
export async function GET(r:NextRequest){try{const l=await oclFetch((r.nextUrl.searchParams.get('q')||'napa').slice(0,40));return NextResponse.json(l.slice(0,1))}catch(e:any){return NextResponse.json({error:e.message},{status:502})}}
