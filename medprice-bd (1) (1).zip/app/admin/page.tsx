'use client';
import {useEffect,useState} from 'react';
const inp='min-h-11 px-3 rounded-lg border border-slate-300 w-full';const btn='min-h-11 px-4 rounded-lg font-semibold bg-emerald-700 text-white';
const api=(p:string,m='GET',b?:any)=>fetch('/api/admin/'+p,{method:m,headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined});
function Manager({kind,fields,title}:{kind:string;fields:any[];title:string}){
 const [rows,setRows]=useState<any[]>([]);const [f,setF]=useState<any>({});const [err,setErr]=useState('');
 const load=()=>api(kind).then(r=>r.json()).then(setRows);useEffect(()=>{load()},[]);
 async function save(e:any){e.preventDefault();setErr('');const r=await api(kind,f.id?'PUT':'POST',f);if(!r.ok){setErr((await r.json()).error);return}setF({});load()}
 return(<section className="bg-white rounded-xl shadow p-4 space-y-3"><h2 className="text-xl font-bold">{title}</h2>
 <form onSubmit={save} className="space-y-2">{fields.map(x=>x.t==='bool'?<label key={x.k} className="flex gap-2"><input type="checkbox" checked={f[x.k]??true} onChange={e=>setF({...f,[x.k]:e.target.checked})}/>{x.l}</label>
  :x.t==='sel'?<select key={x.k} className={inp} value={f[x.k]||'DRAFT'} onChange={e=>setF({...f,[x.k]:e.target.value})}><option value="DRAFT">Draft</option><option value="PUBLISHED">Published</option></select>
  :<div key={x.k}><label className="text-sm">{x.l}</label><input className={inp} type={x.t||'text'} value={f[x.k]?.toString().slice(0,x.t==='datetime-local'?16:999)||''} onChange={e=>setF({...f,[x.k]:e.target.value})}/></div>)}
 {err&&<p className="text-red-700">{err}</p>}<button className={btn}>{f.id?'আপডেট':'তৈরি করুন'}</button>{f.id&&<button type="button" className="ml-2 underline" onClick={()=>setF({})}>বাতিল</button>}</form>
 {rows.map(r=><div key={r.id} className="border-t pt-2 flex flex-wrap gap-2 items-center"><b className="flex-1">{r.title}</b><span className="text-sm">{r.status||(r.active?'Active':'Inactive')}</span>
  <button className="underline" onClick={()=>setF({...r,publishAt:r.publishAt?.slice(0,16),expiresAt:r.expiresAt?.slice(0,16),startAt:r.startAt?.slice(0,16),endAt:r.endAt?.slice(0,16)})}>Edit</button>
  <button className="underline" onClick={async()=>{await api(kind,'PUT',r.status!==undefined?{id:r.id,status:r.status==='PUBLISHED'?'DRAFT':'PUBLISHED'}:{id:r.id,active:!r.active});load()}}>{r.status!==undefined?(r.status==='PUBLISHED'?'Unpublish':'Publish'):(r.active?'Disable':'Enable')}</button>
  <button className="text-red-700 underline" onClick={async()=>{if(confirm('Delete?')){await api(kind+'?id='+r.id,'DELETE');load()}}}>Delete</button></div>)}</section>)}
export default function Admin(){
 const [st,setSt]=useState<any>(null);const [auth,setAuth]=useState<boolean|null>(null);const [e,setE]=useState('');const [p,setP]=useState('');const [err,setErr]=useState('');
 const boot=()=>api('stats').then(async r=>{if(r.ok){setSt(await r.json());setAuth(true)}else setAuth(false)});useEffect(()=>{boot()},[]);
 async function login(ev:any){ev.preventDefault();const r=await api('login','POST',{email:e,password:p});if(r.ok){setErr('');boot()}else setErr('ইমেইল বা পাসওয়ার্ড ভুল')}
 if(auth===null)return null;
 if(!auth)return(<main className="max-w-sm mx-auto p-6 space-y-3"><h1 className="text-2xl font-bold">অ্যাডমিন লগইন</h1><form onSubmit={login} className="space-y-3"><input className={inp} placeholder="Email" value={e} onChange={x=>setE(x.target.value)}/><input className={inp} type="password" placeholder="Password" value={p} onChange={x=>setP(x.target.value)}/>{err&&<p className="text-red-700">{err}</p>}<button className={btn+' w-full'}>লগইন</button></form></main>);
 return(<main className="max-w-3xl mx-auto p-4 space-y-5"><div className="flex justify-between"><h1 className="text-2xl font-bold">অ্যাডমিন ড্যাশবোর্ড</h1><button className="underline" onClick={async()=>{await api('logout','POST');setAuth(false)}}>Logout</button></div>
 <section className="bg-white rounded-xl shadow p-4 grid grid-cols-2 gap-2"><div>মোট সার্চ: <b>{st.total}</b></div><div>সফল: <b>{st.ok}</b></div><div>ব্যর্থ: <b>{st.fail}</b></div><div>ইউজার: <b>{st.users}</b></div>
  <div>কনফিগার্ড প্রোভাইডার: <b>{st.providersConfigured}</b></div><div>সর্বশেষ সফল কল: <b>{st.lastSuccess?new Date(st.lastSuccess).toLocaleString('bn-BD'):'নেই'}</b></div>
  <div className="col-span-2 text-sm"><b>সাম্প্রতিক API লগ</b>{st.logs.map((l:any)=><div key={l.id} className={l.ok?'text-emerald-700':'text-red-700'}>{l.provider} — {l.ok?'OK':l.error}</div>)}</div></section>
 <Manager kind="announcements" title="আপডেট/নিউজ" fields={[{k:'title',l:'Title'},{k:'body',l:'বিবরণ'},{k:'imageUrl',l:'Banner URL (https)'},{k:'publishAt',l:'Publish date',t:'datetime-local'},{k:'expiresAt',l:'Expiry',t:'datetime-local'},{k:'status',t:'sel'}]}/>
 <Manager kind="ads" title="বিজ্ঞাপন" fields={[{k:'title',l:'Title'},{k:'body',l:'Description'},{k:'imageUrl',l:'Image URL (https)'},{k:'link',l:'Link'},{k:'startAt',l:'Start',t:'datetime-local'},{k:'endAt',l:'End',t:'datetime-local'},{k:'active',l:'Active',t:'bool'}]}/>
 </main>)}
